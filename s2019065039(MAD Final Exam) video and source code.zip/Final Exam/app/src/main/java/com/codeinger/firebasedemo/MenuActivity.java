package com.codeinger.firebasedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {


    private Button CV_builder_btn;
    private Button edit_cv_btn;
    private Button search_worker_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        CV_builder_btn = findViewById(R.id.cv_builder_btn);
        edit_cv_btn = findViewById(R.id.edit_cv_btn);
        search_worker_btn=findViewById(R.id.search_worker_btn);


        CV_builder_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent addintent = new Intent(MenuActivity.this, AddPostActivity.class);
                startActivity(addintent);
                finish();
            }
        });

        edit_cv_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent editintent = new Intent(MenuActivity.this,PostListActivity.class);
                startActivity(editintent);
                finish();
            }
        });

        search_worker_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent searchintent = new Intent(MenuActivity.this,PostListActivity.class);
                startActivity(searchintent);
                finish();

            }
        });
    }
}
