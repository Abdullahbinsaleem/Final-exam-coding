package com.codeinger.firebasedemo;

public class Post {

    String Username;
    String Address;
    String Contact;
    String Email;
    String Password;
    String Education;
    String Project;
    String ResearchBackground;
    String KeySkills;

    public Post() {
    }

    @Override
    public String toString() {
        return "Post{" +
                "Name='" + Username + '\'' +
                ", Address ='" + Address + '\'' +
                ", Contact='" + Contact + '\'' +
                ", Email='" + Email + '\'' +
                ", Password='" + Password + '\'' +
                ", Education='" + Education + '\'' +
                ", Project='" + Project + '\'' +
                ", ResearchBackground='" + ResearchBackground + '\'' +
                ", KeySkills='" + KeySkills + '\'' +
                '}';
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getContact() {
        return Contact;
    }

    public void setContact(String contact) {
        Contact = contact;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEducation() {
        return Education;
    }

    public void setEducation(String education) {
        Education = education;
    }

    public String getProject() {
        return Project;
    }

    public void setProject(String project) {
        Project = project;
    }

    public String getResearchBackground() {
        return ResearchBackground;
    }

    public void setResearchBackground(String researchBackground) {
        ResearchBackground = researchBackground;
    }

    public String getKeySkills() {
        return KeySkills;
    }

    public void setKeySkills(String keySkills) {
        KeySkills = keySkills;
    }
}