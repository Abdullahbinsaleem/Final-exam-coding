package com.codeinger.firebasedemo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class AddPostActivity extends AppCompatActivity {

    private EditText Username, email, password, project, research, education, skills, contact, address;
    private TextView text;
    private Button save,read;
    private DatabaseReference Post;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              save();
            }
        });

        read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // readOneTime();
                readRealTime();
            }
        });


    }

    private void readRealTime() {
        Post.child("-Ln9F3Km8HlwqS0oaD9Q")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        String post = "Name : "+dataSnapshot.child("name").getValue(String.class)+"\n"
                                +"Email : "+dataSnapshot.child("email").getValue(String.class)+"\n"
                                +"Project : "+dataSnapshot.child("project").getValue(String.class)+"\n"
                                +"Address : "+dataSnapshot.child("address").getValue(String.class)+"\n"
                                +"Research : "+dataSnapshot.child("research").getValue(String.class)+"\n"
                                +"Contact : "+dataSnapshot.child("contact").getValue(String.class)+"\n"
                                +"Education : "+dataSnapshot.child("education").getValue(String.class)+"\n"
                                +"Skills : "+dataSnapshot.child("skills").getValue(String.class)+"\n"
                                +"Password : "+dataSnapshot.child("password").getValue(String.class);


                        text.setText(post);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    private void readOneTime() {
         Post.child("-Ln9F3Km8HlwqS0oaD9Q")
                 .addListenerForSingleValueEvent(new ValueEventListener() {
                     @Override
                     public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                         String post = "Name : "+dataSnapshot.child("name").getValue(String.class)+"\n"
                                 +"Email : "+dataSnapshot.child("email").getValue(String.class)+"\n"
                                 +"Project : "+dataSnapshot.child("project").getValue(String.class)+"\n"
                                 +"Address : "+dataSnapshot.child("address").getValue(String.class)+"\n"
                                 +"Research : "+dataSnapshot.child("research").getValue(String.class)+"\n"
                                 +"Contact : "+dataSnapshot.child("contact").getValue(String.class)+"\n"
                                 +"Education : "+dataSnapshot.child("education").getValue(String.class)+"\n"
                                 +"Skills : "+dataSnapshot.child("skills").getValue(String.class)+"\n"
                                 +"Password : "+dataSnapshot.child("password").getValue(String.class);

                         text.setText(post);

                     }

                     @Override
                     public void onCancelled(@NonNull DatabaseError databaseError) {

                     }
                 });
    }

    private void save() {
        HashMap<String,Object> map = new HashMap<>();
        map.put("name",Username.getText().toString());
        map.put("email",email.getText().toString());
        map.put("project",project.getText().toString());
        map.put("research",research.getText().toString());
        map.put("skills",skills.getText().toString());
        map.put("address",address.getText().toString());
        map.put("education",education.getText().toString());
        map.put("contacts",contact.getText().toString());
        map.put("password",password.getText().toString());

        Post.push()
                .setValue(map)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Log.i("jfbvkj", "onComplete: ");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Log.i("jfbvkj", "onFailure: "+e.toString());
                    }
                }).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Log.i("jfbvkj", "onSuccess: ");
            }
        });
    }

    private void init() {
        Username =findViewById(R.id.et_name);
        email = findViewById(R.id.et_email);
        project = findViewById(R.id.et_project);
        password = findViewById(R.id.et_password);
        education = findViewById(R.id.et_education);
        skills=findViewById(R.id.et_keyskills);
        research = findViewById(R.id.et_ResearchBackground);
        contact = findViewById(R.id.et_Contact);
        address = findViewById(R.id.et_address);
        save = findViewById(R.id.save);
        read = findViewById(R.id.read);
        text = findViewById(R.id.text);

        Post = FirebaseDatabase.getInstance().getReference().child("Post");
    }


}
